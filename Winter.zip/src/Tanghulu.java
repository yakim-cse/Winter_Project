import java.util.*;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField; 
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.text.Position;
import  java.lang.NullPointerException;
import se.datadosen.component.RiverLayout;

public class Tanghulu {
	// DB 관련 변수들
	Connection conn;		// DB 연결 Connection 객체참조변수

	ImageIcon cover_pic = new ImageIcon("src/초기화면.jpg");
	ImageIcon stock_pic = new ImageIcon("src/재고조회.jpg");
	ImageIcon way_pic = new ImageIcon("src/꿀팁.jpg");
	ImageIcon home_pic = new ImageIcon("src/홈.png");
	
	// 최상위 프레임
	JFrame frame;
	String frameTitle = "金家 탕후루 데이터베이스 클라이언트";

	CoverPanel coverPanel;
	JPanel midPanel;
	WayPanel wayPanel;
	CardLayout card;   
	JPanel buttonPanel;
	JPanel leftTopPanel;
	JPanel tmpPanel;
	JPanel tmpPanel1;
	JPanel tmpPanel2;
	JPanel rightTopPanel;
	JPanel leftBottomPanel;
	JPanel rightBottomPanel;
	JPanel topPanel;
	JPanel bottomPanel;
	StockPanel mainPanel;
	
	// 텍스트 박스들
	JTextField name;			// name 필드 디스플레이를 위한 박스 (탕후루 이름)
	JTextField price;			// price 필드 디스플레이를 위한 박스 (탕후루 가격)
	JTextField calories;		// calories 필드 디스플레이를 위한 박스 (탕후루 칼로리)
	JTextField tray;            // tray 필드 디스플레이를 위한 박스 (탕후루 재고)
	JTextField boxes;			// fruit 필드 디스플레이를 위한 박스 (과일 재고)
	
	// 색인을 위한 박스
	JTextField find;		// 색인을 위한  필드

	// 버튼들
	JButton Search;			// 색인 실행을 위한 버튼
	JButton Save;			// 저장 실행을 위한 버튼
	JButton Delete;			// 삭제 실행을 위한 버튼
	JButton New;
	JButton Print;			// 출력을 위한 버튼
	JButton Preview;		// 미리보기를 위한 버튼
	JButton Home;
	JButton Stock;
	JButton Menu;
	JButton Way;
	
	// 리스트
	JList names = new JList();			// 탕후루 종류를 나열해 주는 리스트


	public static void main(String[] args) {
		Tanghulu client = new Tanghulu();
		client.setUpGUI();
		client.dbConnectionInit();

	}

	private void setUpGUI() {
		// build GUI
		frame = new JFrame(frameTitle);
		
		// 탕후루 메뉴 전체를 보여주는 컨트롤 (왼쪽 상단 패널)
		leftTopPanel = new JPanel(new RiverLayout());
		leftTopPanel.setOpaque(false);
		JScrollPane cScroller = new JScrollPane(names);
		cScroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		cScroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		names.setVisibleRowCount(10);
		names.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		names.setFixedCellWidth(150);
		leftTopPanel.add("br center", new JLabel("탕 후 루 리 스 트"));
		leftTopPanel.add("p center", cScroller);

		// 입력 창들과 라벨 (오른쪽 상단 패널)
		rightTopPanel = new JPanel(new RiverLayout());
		rightTopPanel.setOpaque(false);
		name = new JTextField(20);
		price = new JTextField(20);
		calories = new JTextField(20);
		tray = new JTextField(10);
		boxes = new JTextField(10);
		
		//표식을 위한 라벨들
		rightTopPanel.add("br center", new JLabel("金 家 탕 후 루 메 뉴"));
		rightTopPanel.add("p left", new JLabel("이   름"));
		rightTopPanel.add("tab", name);
		rightTopPanel.add("br", new JLabel("가   격"));
		rightTopPanel.add("tab", price);
		rightTopPanel.add("br", new JLabel("칼  로  리"));
		rightTopPanel.add("tab", calories);
		rightTopPanel.add("p br center", new JLabel("탕  후  루  재  고  현  황"));
		rightTopPanel.add("p center",tray);
		rightTopPanel.add("p br center", new JLabel("과  일  재  고  현  황"));
		rightTopPanel.add("p center", boxes);
		
		//rightTopPanel.setOpaque(false);
		
		// 왼쪽 하단 패널
		leftBottomPanel = new JPanel(new RiverLayout());
		leftBottomPanel.setOpaque(false);
		tmpPanel = new JPanel(new RiverLayout());
		tmpPanel.setOpaque(false);
		tmpPanel1 = new JPanel(new RiverLayout());
		tmpPanel1.setOpaque(false);
		tmpPanel2 = new JPanel(new RiverLayout());
		tmpPanel2.setOpaque(false);
		find = new JTextField(20);
		Search = new JButton("검색");
		Print = new JButton("출력");
		Preview = new JButton("미리보기");
		tmpPanel1.add("center", new JLabel("검  색"));
		tmpPanel1.add("p center",find);
		tmpPanel2.add(Search);
		tmpPanel2.add(Print);
		tmpPanel2.add(Preview);
		tmpPanel.add("center",tmpPanel1);
		tmpPanel.add("br cneter",tmpPanel2);
		leftBottomPanel.add("center", tmpPanel);
		//leftTopPanel.add(leftBottomPanel, BorderLayout.SOUTH);
		//leftBottomPanel.setOpaque(false);
		
		// 오른쪽 하단 패널
		rightBottomPanel = new JPanel(new RiverLayout());
		rightBottomPanel.setOpaque(false);
		tmpPanel = new JPanel(new RiverLayout());
		tmpPanel.setOpaque(false);
		Save = new JButton("저장");
		Delete = new JButton("삭제");
		New = new JButton("신규");
		
		tmpPanel.add(Save);
		tmpPanel.add("tab", Delete);
		tmpPanel.add("tab", New);
		rightBottomPanel.add("center", tmpPanel);
		rightBottomPanel.add("br", Box.createRigidArea(new Dimension(0,20)));
		
		// GUI 배치
		topPanel = new JPanel(new GridLayout(1,2));
		topPanel.setOpaque(false);
		topPanel.add(leftTopPanel);
		topPanel.add(rightTopPanel, BorderLayout.CENTER );
		
	    bottomPanel = new JPanel(new GridLayout(1,2));
	    bottomPanel.setOpaque(false);
		bottomPanel.add(leftBottomPanel);
		bottomPanel.add(rightBottomPanel);
		
		mainPanel = new StockPanel();
		mainPanel.add(topPanel, BorderLayout.CENTER);
		mainPanel.add(bottomPanel, BorderLayout.SOUTH);

		// 초기화면과 게임화면을 레이어화 함
		midPanel = new JPanel();
		midPanel.setOpaque(false);
		coverPanel = new CoverPanel();
		coverPanel.setOpaque(false);
		wayPanel = new WayPanel();
		card = new CardLayout();
		midPanel.setLayout(card);
		midPanel.add("1", coverPanel);
		midPanel.add("2", mainPanel);
		midPanel.add("3", wayPanel);
		
		Stock = new JButton("재고조회");
		Menu = new JButton("메뉴 한눈에 보기");
		Way = new JButton("맛있게 먹는 방법");

		coverPanel.add(Stock);
		coverPanel.add(Menu);
		coverPanel.add(Way);
		
		// ActionListener의 설정
		names.addListSelectionListener(new NameListListener());
		MySearchListener l = new MySearchListener();
		find.addActionListener(l);														// 텍스트 박스에서 리턴 눌러 색인 시작 할 때
		Search.addActionListener(l);													// 버튼으로 색인 시작할 때 동일한 핸들러 사용
		Save.addActionListener(new SaveButtonListener());
		Delete.addActionListener(new DeleteButtonListener());
		New.addActionListener(new NewButtonListener());
		Print.addActionListener(new DisplayButtonListener());
		Preview.addActionListener(new DisplayButtonListener());
		Stock.addActionListener(new ButtonListener());
		Menu.addActionListener(new DisplayButtonListener());
		Way.addActionListener(new ButtonListener());
		
		// 클라이언드 프레임 창 조정
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.getContentPane().add(mainPanel);
		frame.add(BorderLayout.CENTER, midPanel);
		frame.setSize(700,410);
		//frame.getRootPane().setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
		frame.setLocationRelativeTo(null);			//프레임을 중앙으로 정렬시킴
		frame.setResizable(false); 					// 프레임 크기 조절 비활성화
		frame.setVisible(true);
	}
	
	class CoverPanel extends JPanel{
		public void paintComponent(Graphics g) {
			g.drawImage(cover_pic.getImage(), 0,0, getWidth(), getHeight(), this);
			
		}
	}
	
	class StockPanel extends JPanel implements MouseListener{
		
		public StockPanel() {
	        addMouseListener(this);  // StockPanel에 MouseListener 추가
	    }
		
		public void paintComponent(Graphics g) {
			g.drawImage(stock_pic.getImage(), 0,0, getWidth(), getHeight(), this);
			g.drawImage(home_pic.getImage(), 630, 300, this);
			
		}
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			 int mouseX = e.getX();
		        int mouseY = e.getY();

		        // home_pic을 클릭했는지 확인
		        if (mouseX >= 630 && mouseX <= 680 && mouseY >= 300 && mouseY <= 350) {
		            card.show(midPanel, "1"); // cover_panel로 돌아가기
		            names.clearSelection(); // 선택 해제
		        }
		}

		@Override
		public void mousePressed(MouseEvent e) {
			
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	
	class WayPanel extends JPanel implements MouseListener{
		public WayPanel() {
	        addMouseListener(this);  // StockPanel에 MouseListener 추가
	    }
		public void paintComponent(Graphics g) {
			g.drawImage(way_pic.getImage(), 0,0, getWidth(), getHeight(), this);
			g.drawImage(home_pic.getImage(), 8, 300, this);
		}
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			 int mouseX = e.getX();
		        int mouseY = e.getY();

		        // home_pic을 클릭했는지 확인
		        if (mouseX >= 30 && mouseX <= 48 && mouseY >= 300 && mouseY <= 350) {
		            card.show(midPanel, "1"); // cover_panel로 돌아가기
		            names.clearSelection(); // 선택 해제
		        }
		}

		@Override
		public void mousePressed(MouseEvent e) {
			
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}

	private void dbConnectionInit() {
		try {
			Class.forName("com.mysql.jdbc.Driver");					// JDBC드라이버를 JVM영역으로 가져오기
			conn = DriverManager.getConnection("jdbc:mysql://localhost/my_database", "root", "mite");	// DB 연결하기
			prepareList();
		}
		catch (ClassNotFoundException cnfe) {
			System.out.println("JDBC 드라이버 클래스를 찾을 수 없습니다 : " + cnfe.getMessage());
		}
		catch (Exception ex) {
			System.out.println("DB 연결 에러 : " + ex.getMessage());
		}
	}

	// DB에 있는 전체 레코드를 불러와서 리스트에 뿌려주는 메소드
	public void prepareList() {
		try {
			Statement stmt = conn.createStatement();			// SQL 문을 작성을 위한  Statement 객체 생성

			// 현재 DB에 있는 내용 추출해서 강아지 목록을 names 리스트에 출력하기
			ResultSet rs = stmt.executeQuery("SELECT * FROM kg_tanghulu_menu");
			Vector<String> list = new Vector<String>();
			while (rs.next()) {
				list.add(rs.getString("name"));		
			}
			stmt.close();										// statement는 사용후 닫는 습관
			Collections.sort(list);								// 우선 정렬하자
			names.setListData(list);							// names의 각종 속성은 그대로 두고 내용물만 바꾼다
			if (!list.isEmpty())								// 리스트가 바뀌고 나면 항상 첫번째 아이텀을 가리키게 
				names.setSelectedIndex(0);
		} catch (SQLException sqlex) {
			System.out.println("SQL 에러 : " + sqlex.getMessage());
			sqlex.printStackTrace();
		}
	}
	
	private class ButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == Stock) {
				card.show(midPanel, "2");
				mainPanel.setFocusable(true);
				mainPanel.requestFocus();
			}
			
			if(e.getSource() == Way) {
				card.show(midPanel, "3");
				wayPanel.setFocusable(true);
				wayPanel.requestFocus();
			}
			
		}
		
	}

	// 리스트 박스에 액션이 발생하면 처리하는 리스너
	public class NameListListener implements ListSelectionListener {
		public void valueChanged(ListSelectionEvent lse) {					// 리스트의 선택이 바뀔때마다 호출
			if (!lse.getValueIsAdjusting() && !names.isSelectionEmpty()) {  // 현재 선택이 다 끝난 경우에 처리
				try {
					Statement stmt = conn.createStatement();				// SQL 문장 만들기 위한 Statement 객체
					ResultSet rs = stmt.executeQuery("SELECT * FROM kg_tanghulu_menu WHERE name = '" +
							(String)names.getSelectedValue() + "'");
					rs.next();	                                // 여러개가 리턴되어도 첫번째 것으로 사용 
					name.setText(rs.getString("name"));			// DB에서 리턴 된 값을 가지고 택스트 박스 채움
					price.setText(rs.getString("price"));
					calories.setText(rs.getString("calories"));
					// hulu 테이블에서 데이터를 가져오기
					ResultSet rs2 = stmt.executeQuery("SELECT tray FROM hulu h NATURAL JOIN kg_tanghulu_menu ktm WHERE h.name = '" 
							+ (String)names.getSelectedValue() + "'");
					if (rs2.next()) {
						tray.setText(rs2.getString("tray")+" 판");
					} else{
						// 만약 hulu 테이블에서 해당하는 데이터가 없을 경우에 대한 처리
						tray.setText("");
					}
					//tray.setText(rs2.getString("tray"));
					//fruit 테이블에서 데이터를 가져오기
					ResultSet rs3 = stmt.executeQuery("SELECT boxes FROM fruits WHERE name ='"
						       + (String) names.getSelectedValue() + "'");
				    if (rs3.next()) {
						boxes.setText(rs3.getString("boxes")+" 박스");
					} else {
						// 만약 hulu 테이블에서 해당하는 데이터가 없을 경우에 대한 처리
						boxes.setText(" ");
					}
				    
				    
					stmt.close();
				} catch (SQLException sqlex) {
					System.out.println("SQL 에러 : " + sqlex.getMessage());
					sqlex.printStackTrace();
				} catch (Exception ex) {
					System.out.println("DB Handling 에러(리스트 리스너) : " + ex.getMessage());
					ex.printStackTrace();
				}
			}
		}
	}

	// 색인 컴포넌트의 리스너
	public class MySearchListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			int index = names.getNextMatch(find.getText().trim(), 0, Position.Bias.Forward);
			if (index != -1) {
				names.setSelectedIndex(index);
			}
			//Search.setText("");
		}
	}

	// 삭제 버튼의 리스너
	public class DeleteButtonListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			try {
	    		Statement stmt = conn.createStatement();				// SQL 문을 작성을 위한  Statement 객체 생성
	    		stmt.executeUpdate("DELETE FROM hulu WHERE name = '" +
	    				name.getText().trim() + "'");
	    		stmt.executeUpdate("DELETE FROM fruits WHERE name = '" +
	    				name.getText().trim() + "'");
	    		stmt.executeUpdate("DELETE FROM kg_tanghulu_menu WHERE name = '" + 
	    				name.getText().trim() + "'");
	    		stmt.executeUpdate("DELETE FROM tanghulu WHERE tanghulu_id IN " +
	                     "(SELECT tanghulu_id FROM kg_tanghulu_menu WHERE name = '" +
	                     name.getText().trim() + "')");
	    		
	    		stmt.close();
	    		prepareList();											// 리스트 박스 새 리스트로 다시 채움 
	    	} catch (SQLException sqlex) {
	    		System.out.println("SQL 에러 : " + sqlex.getMessage());
	    		sqlex.printStackTrace();
	    	} catch (Exception ex) {
	    		System.out.println("DB Handling 에러(DELETE 리스너) : " + ex.getMessage());
	    		ex.printStackTrace();
	    	}
		}
	}

	// 저장 버튼의 리스너
	public class SaveButtonListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			
			try {
				
				Statement stmt = conn.createStatement();				// SQL 문을 작성을 위한  Statement 객체 생성
				ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM kg_tanghulu_menu WHERE name = '" + name.getText().trim() + "'");
		        rs.next();
		        int count = rs.getInt(1);
		        if (count > 0) {
	                // 이미 존재하는 경우 메시지 박스 표시
	                JOptionPane.showMessageDialog(frame, "이미 존재합니다.");
	            } else {
	            	stmt.executeUpdate("DELETE FROM pet WHERE name = '" +	// 현재 레코드 삭제하고 (name 필드는 변함이 없다고 가정)
							name.getText().trim() + "'");
					stmt.executeUpdate("INSERT INTO kg_tanghulu_menu (name, price, calories) VALUES ('" +	// 새 레코드로 변경
							name.getText().trim() + "', '" +
							price.getText().trim() + "', '" +
							calories.getText().trim() +  "')");
					stmt.executeUpdate("INSERT INTO hulu (tanghulu_id, name, tray) SELECT tanghulu_id, name, " + tray.getText().trim() + " FROM kg_tanghulu_menu WHERE name = '" + name.getText().trim() + "'");
				    stmt.executeUpdate("INSERT INTO fruits (name,  boxes) SELECT name, " + boxes.getText().trim() + " FROM kg_tanghulu_menu WHERE name = '" + name.getText().trim() + "'");
				    stmt.executeUpdate("INSERT INTO tanghulu (tanghulu_id, fruit_id) SELECT ktm.tanghulu_id, f.fruit_id " +
			                   "FROM kg_tanghulu_menu ktm " +
			                   "JOIN fruits f ON ktm.name = f.name " +
			                   "WHERE ktm.name = '" + name.getText().trim() + "'");
	            }
				
				stmt.close();
				prepareList();											// 다시 뿌려 
				int index = names.getNextMatch(name.getText().trim(), 0, Position.Bias.Forward);
				names.setSelectedIndex(index);
			} catch (SQLException sqlex) {
				System.out.println("SQL 에러 : " + sqlex.getMessage());
				sqlex.printStackTrace();
			} catch (Exception ex) {
				System.out.println("DB Handling 에러(SAVE 리스너) : " + ex.getMessage());
				ex.printStackTrace();
			}
		}
	}

	public class NewButtonListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			name.setText("");
			price.setText("");
			calories.setText("");
			tray.setText("");
			boxes.setText("");
			names.clearSelection();
		}
	}

	// 출력을 위한 액션이 발생하면 처리하는 리스너 (print와 preview)
	public class DisplayButtonListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			// DB에서 가져오는 데이터를 rowObjects의 형태로 저장하고 이들의 리스트를 Printer 또는 Preview로 보내 줌
			ArrayList<RowObjects> rowList = new ArrayList<RowObjects>();	// 행들의 리스트
			RowObjects line;												// 하나의 행
			PrintObject word;												// 하나의 단어
			try {
				Statement stmt = conn.createStatement();					// SQL 문장 만들기 위한 Statement 객체
				ResultSet rs = stmt.executeQuery("SELECT * FROM kg_tanghulu_menu");
				while(rs.next()) {
					line = new RowObjects();								// 5개의 단어가 1줄
					line.add(new PrintObject(rs.getString("name"), 30));
					line.add(new PrintObject(rs.getString("price"), 20));
					//line.add(new PrintObject(rs.getString("calories"), 20));
					if (rs.getString("calories") != null) {
						line.add(new PrintObject(rs.getString("calories"), 20));
				    } else {
				    	line.add(new PrintObject("NULL", 20)); // calories가 null일 때 대체할 값이나 처리를 추가하세요.
				    }
					rowList.add(line);										// 출력해야 될 전체 리스트를 만듬									
				}
				stmt.close();

				// 각 페이지의 칼럼 헤더를 위해 한 줄 만들음
				line = new RowObjects();									
				line.add(new PrintObject("이름", 30));
				line.add(new PrintObject("가격", 20));
				line.add(new PrintObject("칼로리", 20));

				if (e.getSource() == Print) {
					Printer prt = new Printer(new PrintObject("金家탕후루 메뉴", 20), line, rowList, true);
					prt.print();
				}
				else if (e.getSource() == Preview || e.getSource() == Menu) {
					Preview prv = new Preview(new PrintObject("金家탕후루 메뉴", 20), line, rowList, true);
					prv.preview();
				}

			} catch (SQLException sqlex) {
				System.out.println("SQL 에러 : " + sqlex.getMessage());
				sqlex.printStackTrace();
			} catch (Exception ex) {
				System.out.println("DB Handling 에러(리스트 리스너) : " + ex.getMessage());
				ex.printStackTrace();
			}	
		}
	}
}
